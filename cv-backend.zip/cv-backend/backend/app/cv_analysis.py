import pdfplumber
from langdetect import detect
from sentence_transformers import SentenceTransformer, util
from transformers import pipeline
import language_tool_python

# ============================
# 1. Anahtar Kelimeler ve Ağırlıklar
# ============================
criteria_labels = {
    "iş_deneyimi": ["İş Deneyimi", "Work Experience", "Career History", "Experience"],
    "egitim": ["Eğitim", "Education", "Academic Background", "University"],
    "teknik_beceriler": ["Teknik Beceriler", "Technical Skills", "Skills"],
    "ozet": ["Özet", "Hakkımda", "Summary", "Profile", "Objective"],
    "liderlik": ["Liderlik", "Leadership", "Organization Experience"],
    "sertifikalar": ["Sertifikalar", "Certificates", "Certifications", "Courses"],
    "iletisim": ["İletişim", "Contact", "Phone", "Email"],
    "portfolyo": ["Portfolyo", "Portfolio", "GitHub", "Website"],
    "diller": ["Diller", "Languages"],
    "referanslar": ["Referanslar", "References"]
}

criteria_weights = {
    "iş_deneyimi": 25,
    "egitim": 15,
    "teknik_beceriler": 15,
    "ozet": 10,
    "liderlik": 10,
    "sertifikalar": 10,
    "iletisim": 5,
    "portfolyo": 5,
    "diller": 3,
    "referanslar": 2
}

# ============================
# 2. Modeller
# ============================
semantic_model = SentenceTransformer('all-MiniLM-L6-v2')
classifier = pipeline("zero-shot-classification", model="MoritzLaurer/mDeBERTa-v3-base-mnli-xnli")

# ============================
# 3. PDF Metin Çıkarma
# ============================
def extract_text_from_pdf(path):
    text = ""
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n"
    return text

# ============================
# 4. İmla ve Dilbilgisi Kontrolü
# ============================
def grammar_check(text, lang_code):
    tool = language_tool_python.LanguageTool("en-US" if lang_code == "en" else "tr")
    matches = tool.check(text[:5000])
    return [m.message for m in matches]

# ============================
# 5. CV Analizi
# ============================
def analyze_cv(text):
    lang = detect(text)
    text_lower = text.lower()
    total_score = 0
    strengths, weaknesses = [], []

    for section, labels in criteria_labels.items():
        max_score = 0

        # --- 5.1 Anahtar Kelime Kontrolü ---
        for kw in labels:
            if kw.lower() in text_lower:
                max_score = 1.0
                break

        # --- 5.2 Semantik Benzerlik ---
        if max_score < 1.0:
            e1 = semantic_model.encode(text, convert_to_tensor=True)
            e2 = semantic_model.encode(" ".join(labels), convert_to_tensor=True)
            sim = float(util.cos_sim(e1, e2))
            if sim > 0.4:
                max_score = sim

        # --- 5.3 Zero-Shot ---
        if max_score < 0.4:
            try:
                result = classifier(text[:512], candidate_labels=labels, multi_label=True)
                max_score = max(result["scores"])
            except:
                pass

        # --- 5.4 Puanlama ---
        score = round(criteria_weights[section] * max_score, 2)
        total_score += score

        if max_score >= 0.6:
            strengths.append(f"{section.replace('_',' ').title()} bölümü mevcut ve yeterli.")
        elif max_score >= 0.4:
            weaknesses.append(f"{section.replace('_',' ').title()} bölümü zayıf.")
        else:
            weaknesses.append(f"{section.replace('_',' ').title()} bölümü eksik.")

    total_score = round(total_score, 2)
    return {
        "language": "English" if lang == "en" else "Türkçe",
        "total_score": total_score,
        "strengths": strengths,
        "weaknesses": weaknesses,
        "grammar_issues": grammar_check(text, lang)
    }