from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
import tempfile
from cv_analysis import extract_text_from_pdf, analyze_cv

app = FastAPI()

# CORS (React vb. istemciler için)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/analyze/")
async def analyze(file: UploadFile = File(...)):
    # PDF'i geçici olarak kaydet
    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
        tmp.write(await file.read())
        path = tmp.name
    text = extract_text_from_pdf(path)
    return analyze_cv(text)

@app.get("/health")
def health():
    return {"status": "ok"}